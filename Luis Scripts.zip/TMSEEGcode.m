% Adapted by CS, July 2023
% this version takes 13 minutes to run from start to finish

% This is an example script for cleaning standard TMS-EEG data

% Depedencies:
%
% 1. Matlab, tested with R2022b
%
% 1. Fastica package, version  https://research.ics.aalto.fi/ica/fastica/
%
% 2. EEGLAB toolbox, tested with version 2022_1 https://sccn.ucsd.edu/eeglab/index.php
%
% 3. TESA EEGLAB plugin, version 1.1.1 https://nigelrogasch.github.io/TESA/
%
% Installation:
%
% 1. Download and extract the Fastica package. Define the path to the Fastica package in the beginning of the Matlab script.
%
% 2. Download and extract EEGLAB package. Define the path to the EEGLAB
% package in the beginning of the Matlab script. Add the command <eeglab;> to your
% script
%
% 3. Download and extract the TESA package to ~/path_to_eeglab/eeglab2022.1/plugins

% Tuomas Mutanen 24.05.2023

%% 1. Initate the script

disp('Cell 1 started: Initiating the script...')

clear;
close all;
clc;

% Add path to the eeglab path containing TESA 1.1.1.
addpath('/usr/local/share/eeglab2023.1')

%addpath('/usr/local/share/eeglab/eeglab2022.0')
addpath('/data2/2003/Analysis_scripts/Finland_scripts/Button_scripts')
addpath('/data2/2003/Analysis_scripts/UsefulFunctions')

% Launch eeglab and generate an empty EEGLAB structure:
eeglab;
eeglab_path='/usr/local/share/eeglab/eeglab2020_0';

% Add path to the Fastica package

addpath('/data2/2003/Analysis_scripts/Finland_scripts/FastICA_25')

%% Cell 2. Load raw dataset to EEGLAB

% select the subject number
FileDir='/data/OPTE/Data/005/Data/Baseline TMSEEG/TMSEEG';
selectedFilename = displayFileList('/data/OPTE/Data/005/Data/Baseline TMSEEG/TMSEEG');
newDir=[FileDir '/' selectedFilename];

% select the session number
selectedFilename = displayFileList(newDir);
cd([newDir '/' selectedFilename])
FileDir=[]; FileDir=[newDir '/' selectedFilename '/'];
listtemp=dir('*vhdr'); % list all conditions within a directory

% select the region of interest
terms = {'DLPFC', 'motor', 'angular gyrus'};
selectedItem = displayItemList(terms);


fieldnumbers=[];
if strcmp(selectedItem,'DLPFC')
    for i=1:numel(listtemp)
        if contains(listtemp(i).name,'DLP') | contains(listtemp(i).name,'dlp')
            fieldnumbers = [fieldnumbers, i];
        end
    end
elseif strcmp(selectedItem,'motor')
    for i=1:numel(listtemp)
        if contains(listtemp(i).name,'otor') | contains(listtemp(i).name,'OTOR')
            fieldnumbers = [fieldnumbers, i];
        end
    end
elseif strcmp(selectedItem,'angular gyrus')
    for i=1:numel(listtemp)
        if contains(listtemp(i).name,'ngular') | contains(listtemp(i).name,'NGULAR')
            fieldnumbers = [fieldnumbers, i];
        end
    end
end


% find the sham conditions if they exist
idx=~cellfun('isempty',strfind({listtemp(fieldnumbers).name},'ham'));

if any(idx)
    msgbox(sprintf('Sham trials exist and will be concatenated at the end of 60 real stimulation trials'));
    ShamCond=listtemp(fieldnumbers(idx));
    fieldnumbers=fieldnumbers(~idx);
    Shamname=ShamCond.name;
    EEGsham = pop_loadbv(FileDir, Shamname);
    EEGsham = pop_chanedit(EEGsham, 'lookup',fullfile(eeglab_path,'plugins','dipfit','standard_BESA','standard-10-5-cap385.elp'),...
        'settype',{'' 'EEG'},'settype',{'1:62' 'EEG'});
    EEGsham = pop_select(EEGsham,'nochannel',{'63','64'}); % these electrodes cannot be found?
    eventIndices=find(strcmp({EEGsham.event.type},'T  1'));
    for i=1:length(eventIndices)
        EEGsham.event(eventIndices(i)).type = 'sham';
    end
end
list=listtemp(fieldnumbers);
terms=cell(1);
for li=1:length(list)
    terms{li}=list(li).name
end
% select the region of interest
selectedFilename = displayItemList(terms);


%for l=1:length(list) % if you want to look at one session at a time then enter the number of that session

name=selectedFilename;
msgbox(sprintf([erase(name, '.vhdr')]));

mkdir(FileDir,[erase(name, '.vhdr')]);

if length(strfind(name,'ingle'))>0
    BaseWindow=-5;
    time_interval_of_interest = [-5 10]; % ( in ms  w.r.t. TMS trigger)
    artifact_time_interval = [-2 5]; % ( in ms  w.r.t. TMS trigger)
    artifact_time_interval2 = [-3 7]; % ( in ms  w.r.t. TMS trigger)
    eventMarker={'T  1'}; % paired pulse for the paired protocols and T 1 for the single pulse protocols
elseif length(strfind(name,'xcit'))>0
    eventMarker={'P  1'}; % paired pulse for the paired protocols and T 1 for the single pulse protocols
    time_interval_of_interest = [-16 10]; % ( in ms  w.r.t. TMS trigger)
    artifact_time_interval = [-13 5]; % ( in ms  w.r.t. TMS trigger)
    artifact_time_interval2 = [-14 7]; % ( in ms  w.r.t. TMS trigger)
    BaseWindow=-16;
elseif length(strfind(name,'hibit'))>0
    eventMarker={'P  1'}; % paired pulse for the paired protocols and T 1 for the single pulse protocols
    time_interval_of_interest = [-8 10]; % ( in ms  w.r.t. TMS trigger)
    artifact_time_interval = [-5 5]; % ( in ms  w.r.t. TMS trigger)
    artifact_time_interval2 = [-6 7]; % ( in ms  w.r.t. TMS trigger)
    BaseWindow=-8;
    
end

EEG = pop_loadbv(FileDir, name);


%% 3. Find the theoretical channel locations:
disp('Cell 3 started:  Finding the theoretical channel locations...')

% Compare the channel labels of the dataset to the general EEG channel
% layout template and look for the theoretical coordinates on a sphere.
%
% Useful for at least visualization and for some spatial filtering methods
% that are not used here.

EEG = pop_chanedit(EEG, 'lookup',fullfile(eeglab_path,'plugins','dipfit','standard_BESA','standard-10-5-cap385.elp'),...
    'settype',{'' 'EEG'},'settype',{'1:62' 'EEG'});

EEG = pop_select(EEG,'nochannel',{'63','64'}); % these electrodes cannot be found?

%% 4. Epoch the data around the pulse:

disp('Cell 4 started:  Epoching the data around the pulse...')

time_interval_of_interest = [-1.5 1.5]; % ( in s  w.r.t. TMS trigger):

EEG = pop_epoch( EEG,eventMarker, time_interval_of_interest  , 'newname', 'orig epochs', 'epochinfo', 'yes');
if exist('EEGsham')
    EEGsham = pop_epoch( EEGsham,{'sham'}, time_interval_of_interest  , 'newname', 'orig epochs', 'epochinfo', 'yes');
end

%% 5. Baseline-correct the data:

disp('Cell 5 started: Performing the baseline correction to the data...')

% Baseline correction is performed: the average of prestimulus period
% defined in baseline_time_interval is subtracted from the data epochs

baseline_time_interval = [-500 BaseWindow]; %(in ms w.r.t. TMS)

EEG = pop_rmbase( EEG, baseline_time_interval  ,[]);

if exist('EEGsham')
    EEGsham = pop_rmbase( EEGsham, baseline_time_interval  ,[]);
end

% Check visually the raw (before preprocessing) evoked data:
figure; pop_timtopo(EEG, [-200  500], [20  40  60  80], 'ERP data and scalp maps of orig epochs');

% Visualize the data also on average reference:

EEG_plot = pop_reref( EEG, []);
figure; pop_timtopo(EEG_plot, [-200  500], [20  40  60  80], 'ERP data and scalp maps of orig epochs');
%figure; pop_timtopo(EEG_plot, [-100  300], [20  40  60  80], 'ERP data and scalp maps of orig epochs');

%%%%%%%%%%%%%%%%%%%%%%%%%


prompt='Is there divergence across electrodes? type Yes or No';
dlgtitle='Divergence';
dims=[1 50];
%%%%%%%%%%%%%%%%%%%%%%%%%


answer=inputdlg(prompt,dlgtitle,dims);
if ~isempty(answer) && strcmp(answer,'Yes')
    EEG = divergenceCorrection(EEG, baseline_time_interval);
else
    disp('Doing nothing')
end

figure; pop_timtopo(EEG, [-200  500], [20  40  60  80], 'ERP data and scalp maps of orig epochs');

prompt='Is the divergence cleaned? type Yes or No';
dlgtitle='Divergence';
dims=[1 50];
%%%%%%%%%%%%%%%%%%%%%%%%%


answer=inputdlg(prompt,dlgtitle,dims);
if ~isempty(answer) && strcmp(answer,'Yes')
    disp('Great!')
else
    disp('Stop preprocessing this subject!')
end


%% 6. Let's remove the TMS pulse artifact and interpolate the missing time points with cubic spline:

disp('Cell 6 started: Removing the TMS pulse artifact...')

% First visualize the TMS-pulse artifact to confirm the time-interval to be
% removed.

figure; pop_timtopo(EEG, time_interval_of_interest, [NaN], 'ERP data and scalp maps of orig epochs');

% Remove the time-interval containing the pulse artifact.

EEG = pop_tesa_removedata( EEG, artifact_time_interval);
if exist('EEGsham')
    EEGsham = pop_tesa_removedata( EEGsham, artifact_time_interval);
end
% Interpolate the snipped time window:

%EEG = pop_tesa_interpdata( EEG, 'cubic', [1 1] ); % Uses 1 ms of data before and after the snipped interval in the interpolation

% Visualize the outcome:
figure; pop_timtopo(EEG, [-5 20], [NaN], 'ERP data and scalp maps of orig epochs');
figure; pop_timtopo(EEG, [-100  200], [20  40  60  80], 'ERP data and scalp maps of orig epochs');

%% Cell 6a. Check the data for bad channels and trials:

disp('Cell 6a started: Check the data for bad channels:')

% Save the original dataset with all the channel locations to your preferred path.
% This dataset will be needed later on to extrapolate the (possibly) removed channels:

EEG_tmp = EEG;
EEG = pop_select( EEG, 'trial',1);
EEG.setname=[[erase(name, '.vhdr')] 'data_with_bad_channels'];
EEG = eeg_checkset( EEG );
EEG_orig = pop_saveset( EEG, 'filename',[EEG.setname '.set'],'filepath',[FileDir,[erase(name, '.vhdr')]]);
EEG = EEG_tmp;

% concatanate real and sham blocks before ICA
if exist('EEGsham')
    EEG = pop_mergeset(EEG,EEGsham);
end


% Visualize the average response on average reference to
% identify possible bad channels

EEG_plot = pop_select( EEG, 'time', [-0.1 0.3] );
EEG_plot = pop_reref( EEG_plot, []);

% Adjust the y-axis scale appropriately:
y_scale = [-20 20];

figure; pop_plottopo(EEG_plot, [] , '', 0, 'ydir',1,'ylim', y_scale );

% Remove bad channels from further analysis:
%
% When GUI pops up, click "scroll data" to view continuous data plot.
% Click the three dots and select bad channels from
% the list. Once selected, tick on the option "on->remove these" for the
% "Channel range". Click ok, to finalize the removal.
%pop_eegplot( EEG_plot, 1, 1, 1);
%[EEG, indelec] = pop_rejchan(EEG,'threshold', 5, 'norm', 'on', 'measure', 'kurt')
EEG = pop_select( EEG);

% Visualize data after removal of bad channels:

EEG_plot = pop_reref( EEG, []);

figure; pop_timtopo(EEG_plot,[-200  500], [20  40  60  80], 'ERP data and scalp maps of orig epochs');
figure; pop_timtopo(EEG_plot, [-100  300], [20  40  60  80], 'ERP data and scalp maps of orig epochs');

close all

%% Cell 7.

disp('Cell 7 started: Check the data for bad trials. Click any contaminated trials to turn them yellow. In the end click "reject"')

% Visualize the trials. Click any contaminated trials to turn them
% yellow. In the end click "reject"

% Visualize the data on average reference:

EEG_plot = pop_reref( EEG, []);

% EEG = pop_jointprob(EEG,1,[1:size(EEG.data,1)] ,4,4,0,0); % click Update marks after your are done, this should give a TMPREJ variable
% EEG.BadTr=unique([find(EEG.reject.rejjp==1)])
% EEG = pop_rejepoch(EEG,EEG.BadTr,0);

pop_eegplot( EEG_plot, 1, 1, 1);
uiwait;

EEG.setname=[[erase(name, '.vhdr')] '_after_trial_selection'];
EEG = eeg_checkset( EEG );
EEG = pop_saveset( EEG, 'filename',[EEG.setname '.set'],'filepath',[FileDir,[erase(name, '.vhdr')]]);

disp('Finalize Cell 7 by clicking "reject" when you have identified the bad trials.')
disp('-------------------------------------------------------------------')

%% 8. Detrend the epochs:
EEG = pop_resample( EEG, 5000);

disp('Cell 8: Detrending the epochs...');

% Fit and remove the slow drifts using a  linear model:

EEG = pop_tesa_detrend( EEG, 'linear', [-1500 1499] );

% Visualize the outcome
figure; pop_timtopo(EEG, [-1000  1000], [20  40  60  80], 'ERP data and scalp maps of orig epochs');

disp('Cell 8 ended')
disp('-------------------------------------------------------------------')

%% Cell 9a. Run ICA to remove ocular artifacts and TMS-independent muscular activity

disp('Cell 9a started: Run FastIca, and remove the contaminated components.');

% Baseline correct prior to ICA:

EEG = pop_rmbase( EEG, baseline_time_interval  ,[]);


% Before ICA calculation, set the compression level. This will
% determine the number of independent components extracted. Default here is
% 30, lower level can be set for faster convergence or if the true effective dimensionality of EEG seems clearly lower than 30:


EEG = pop_tesa_pcacompress( EEG, 'compVal', 30, 'plot','on' );

% Run ICA and if EEGsham exists, then look at the second half of the trials
% for artifacts

EEG = pop_tesa_fastica( EEG, 'approach', 'symm', 'g', 'tanh', 'stabilization', 'off' );

EEG = pop_tesa_compplot( EEG,'figSize','medium','plotTimeX',[-500 500],'plotFreqX',[1 100], 'freqScale','log', 'saveWeights','off' );

% remove the EEGsham events at the end
if exist('EEGsham')
    EEG=pop_selectevent(EEG,'type',eventMarker);
end

% Visualize the average response on average reference to
% identify possible bad channels

y_scale = [-20 20];

EEG = pop_select( EEG);

pop_eegplot(EEG, 1, 1, 1);
uiwait;

% Adjust the y-axis scale appropriately:
y_scale = [-20 20];


close all
disp('Cell 9a ended')
disp('-------------------------------------------------------------------')

%% Cell 9b. Baseline correct after ICA and visualize:

disp('Cell 9b: Baseline correction and visualization after ICA.');

EEG = pop_rmbase( EEG, baseline_time_interval  ,[]);

EEG.setname=[[erase(name, '.vhdr')] '_AfterICA'];
EEG = eeg_checkset( EEG );
EEG = pop_saveset( EEG, 'filename',[EEG.setname '.set'],'filepath',[FileDir,[erase(name, '.vhdr')]]);


% Visualize the data on average reference:
EEG_plot = pop_reref( EEG, []);
figure; pop_timtopo(EEG_plot, [-100  200], [20  40  60  80], 'ERP data and scalp maps of orig epochs');
message='Is the data too noisy? Then increase the lambda value from 0.01 in the next UI';
msgbox(sprintf(message))
uiwait

disp('Cell 9b ended')
disp('-------------------------------------------------------------------')

%% Cell 10. Run SOUND to detect and suppress noise coming from extracranial sources.

disp('Cell 10 started: Run SOUND to detect and suppress noise coming from extracranial sources. \n Bad channels will be extrapolated by SOUND ');

disp('NOTE: SOUND transforms the dataset automatically to the average reference! ');

% SOUND automatically extrapolates the channels already removed earlier.
% For this, you have to provide a EEGLAB dataset with all the original
% channels.
EEG.setname=[[erase(name, '.vhdr')] 'data_with_bad_channels'];
data_with_all_channels=[[FileDir,[erase(name, '.vhdr')]] '/' EEG.setname '.set'];

%data_with_all_channels = EEG_orig; %[mainpath,'data_with_bad_channels.set'];

% Run the SOUND algorithm. Regularization level/lambda value can be
% adjusted to control the amount of cleaning. A higher value removes more
% noise, but increases risk of over-correction.
% For details about SOUND, see:
% Mutanen et al. 2018: Automatic and robust noise suppression in EEG and MEG: The SOUND algorithm
% https://www.sciencedirect.com/science/article/pii/S1053811917308480?via%3Dihub

% We can utilize subject-specific leadfield:
%  EEG = pop_tesa_sound(EEG, 'lambdaValue', 0.01, 'iter', 5, 'leadfieldInFile' ,...
%     'lead_field_econ.mat', 'leadfieldChansFile', [],'replaceChans', data_with_all_channels, 'multipleConds', []);

%EEG = pop_interp(EEG,eeg_mergelocs(EEG_orig.chanlocs),'spherical');
Repe=0;
while Repe < 1
    EEGtemp=[];
    pause(2)
    prompt='Use a lambda value between 0.001 and 0.1 based on your noise level. Start with 0.01 and increase in 0.01 increments';
    dlgtitle='Lambda';
    dims=[1 50];
    
    answer=inputdlg(prompt,dlgtitle,dims);
    
    if ~isempty(answer)
        lam=answer{1};
        disp(['Lambda= ', lam]);
    else
        disp('No input provided')
    end
    
    
    % Or you can test the spherical model if you want:
    EEGtemp = pop_tesa_sound(EEG, 'lambdaValue', str2num(lam), 'iter', 5, 'leadfieldInFile' ,[],  'leadfieldChansFile', [], 'replaceChans', data_with_all_channels, 'multipleConds', []);
    
    % Visually inspect the data:
    figure; pop_timtopo(EEGtemp, [-100  200], [20  40  60  80 100 180], 'ERP data and scalp maps of orig epochs');
    
    % Save the current dataset to your preferred path:
    %EEG = pop_saveset( EEG, 'filename',[data_name, '_after_SOUND.set'],'filepath',mainpath);
    
    % Visualize the average response on average reference to
    % identify possible bad channels
    
    EEG_plot = pop_select( EEG, 'time', [-0.1 0.3] );
    EEG_plot = pop_reref( EEG_plot, []);
    
    % Adjust the y-axis scale appropriately:
    y_scale = [-20 20];
    
    disp('Cell 10 ended')
    disp('-------------------------------------------------------------------')
    
    %% Cell 11. Run SSP-SIR to suppress any remaining TMS-evoked muscle artifcats:
    
    disp('Cell 11 started: Run SSP-SIR to suppress any remaining TMS-evoked muscle artifcats');
    
    % For details about SSP-SIR, see:
    % Mutanen et al. 2018: Recovering TMS-evoked EEG responses masked by muscle artifacts
    % https://www.sciencedirect.com/science/article/pii/S1053811916301495?via%3Dihub
    
    % Run the TESA implementation of SSP-SIR:
    % You can either find the correct time-interval for the TMS-evoked muscle artifact automatically if the artifact is large (hundreds of uV):
    %  EEGtemp = pop_tesa_sspsir( EEGtemp, 'artScale','automatic','PC',[]);
    
    artifactWindow=[0 50];
    EEGtemp = pop_tesa_sspsir( EEGtemp, 'artScale','manualConstant','timeRange',artifactWindow,'PC',[]);
    
    % or you can manually set the artifact time interval if the artifact is small (< 100 uV)
    % We can utilize subject-specific leadfield:
    %EEG = pop_tesa_sspsir( EEG, 'leadfieldIn','lead_field_econ.mat','artScale','manual','timeRange',[0 20] ,'PC',[]);
    
    % Or you can test the spherical model if you want:
    %EEG = pop_tesa_sspsir( EEG, 'artScale','manual','timeRange',[0,12],'PC',[]);
    
    
    % Baseline correct, just in case:
    EEGtemp = pop_rmbase( EEGtemp, baseline_time_interval  ,[]);
    
    % Visualize the response
    figure; pop_timtopo(EEGtemp, [-50  200], [20 40 60 100 180], 'ERP data and scalp maps');
    
    prompt2='Are you happy with the results (1) or repeat? (0)';
    dlgtitle='Repeat?';
    dims=[1 50];
    
    
    answer2=inputdlg(prompt2,dlgtitle,dims);
    
    if ~isempty(answer2)
        Repe=answer2{1};
        disp(['Repeat? ', Repe]);
    else
        disp('No input provided')
    end
    
    if str2num(Repe) == 1
        EEG=EEGtemp;
        break
    else Repe = 0;
    end
    close all;
    
end

% Visualize the data on average reference:

EEG_plot = pop_reref( EEG, []);

% EEG = pop_jointprob(EEG,1,[1:size(EEG.data,1)] ,4,4,0,0); % click Update marks after your are done, this should give a TMPREJ variable
% EEG.BadTr=unique([find(EEG.reject.rejjp==1)])
% EEG = pop_rejepoch(EEG,EEG.BadTr,0);

pop_eegplot( EEG_plot, 1, 1, 1);
uiwait;

% Save the current dataset to your preferred path:
EEG.setname=[[erase(name, '.vhdr')] '_after_SSPSIR'];
EEG = eeg_checkset( EEG );
EEG = pop_saveset( EEG, 'filename',[EEG.setname '.set'],'filepath',[FileDir,[erase(name, '.vhdr')]]);


disp('Cell 11 ended')
disp('-------------------------------------------------------------------')

%% Cell 12. Remove the artifact time zone and interpolate

% Remove the time-interval containing the pulse artifact and some residual muscle artifact (optional).


EEG = pop_tesa_removedata( EEG, artifact_time_interval2);

% Interpolate the snipped time window:

EEG = pop_tesa_interpdata( EEG, 'cubic', [1 1] ); % Uses 1 ms of data before and after the snipped interval in the interpolation

% Visualize the response
figure; pop_timtopo(EEG, [-50  200], [20 40 60 80], 'ERP data and scalp maps');


%% Cell 13. Band-pass filter the data with EEGLAB FIR filters:

disp('Cell 13: Band-pass filter...')

% The data is band-pass filtered to remove high frequency signal which is
% unlikely to reflect neural activity and slow drifts that may occur with
% DC amplifiers

l_cut_of_freq = 1;
h_cut_of_freq = 100;

EEG = pop_eegfiltnew(EEG, 'locutoff',l_cut_of_freq ,'hicutoff',h_cut_of_freq);

% OPTIONAL: Bandstop filtering. Can be used to attenuate noise around 50Hz from electrical interference.
% Uncomment to use.

bandstop_limits = [58 62];
EEG = pop_eegfiltnew(EEG, 'locutoff',bandstop_limits(1),'hicutoff',bandstop_limits(2),'revfilt',1,'plotfreqz',1);

% Baseline correct, just in case:
EEG = pop_rmbase( EEG, baseline_time_interval  ,[]);

% Visually inspect the data:
figure; pop_timtopo(EEG, [-50  200], [20  40  60  80], 'ERP data and scalp maps of orig epochs');

disp('Cell 13 ended')
disp('-------------------------------------------------------------------')

%% Cell 14.  Snip of the terminals of the time interval that are not interesting.

disp('Cell 14: Snipping of the fist and last 200 ms of the epochs to remove possible edge effects')


% We can now downsample the data:
EEG = pop_resample( EEG, 1000);

% Snip off the ends just in case
EEG = pop_select( EEG, 'time', [-1 1] );


disp('Cell 14 ended')
disp('-------------------------------------------------------------------')


%% Cell 15. Finally, check trials again and make sure no bad trials remain:

disp('Cell 15 started: Check the data for bad trials. Click any contaminated trials to turn them yellow. In the end click "reject"')

% Inspect and remove bad trials as earlier

pop_eegplot( EEG, 1, 1, 1);

disp('Finalize Cell 15 by clicking "reject" when you have identified the bad trials.')
disp('-------------------------------------------------------------------')


%% Cell 16. Visualize the final result:

close all;

disp('Cell 16: Visualizing the final results...')

% Visually inspect the final data:
figure; pop_timtopo(EEG, [-100  200], [20  40  60  80 100 180], 'Butterfly plot and scalp maps of final TEPs');

EEG_plot = pop_select( EEG, 'time', [-0.1 0.3] );
figure; pop_plottopo(EEG_plot, [] , 'Final cleaned data', 0, 'ydir',1); clear EEG_plot;

disp('Cell 16 ended')
disp('-------------------------------------------------------------------')


%% Cell 17. Save the cleaned data:

disp('Cell 17: Saving the final cleaned version of the data...')


EEG.setname=[[erase(name, '.vhdr')] '_cleaned'];
EEG = eeg_checkset( EEG );
EEG = pop_saveset( EEG, 'filename',[EEG.setname '.set'],'filepath',[FileDir,[erase(name, '.vhdr')]]);

disp('Cell 17 ended')
disp('-------------------------------------------------------------------')
close all

% Step 22: Extract ROI
% looked at Human Brain atlas + Koessler et al Automated Cortical
% Projection of EEG sensors
EEG = pop_tesa_tepextract( EEG, 'ROI', 'elecs', {'C1','C3'}, 'tepName', 'LeftMotor' );
EEG = pop_tesa_tepextract( EEG, 'ROI', 'elecs', {'C2','C4'}, 'tepName', 'RightMotor' );
EEG = pop_tesa_tepextract( EEG, 'ROI', 'elecs', {'F3'}, 'tepName', 'LeftFPN' );
EEG = pop_tesa_tepextract( EEG, 'ROI', 'elecs', {'F4'}, 'tepName', 'RightFPN' );
EEG = pop_tesa_tepextract( EEG, 'ROI', 'elecs', {'P3','P1'}, 'tepName', 'LeftDMN' );
EEG = pop_tesa_tepextract( EEG, 'ROI', 'elecs', {'P4','P2'}, 'tepName', 'RightDMN' );

% Step 22: Find peaks of interest
EEG = pop_tesa_peakanalysis( EEG, 'ROI', 'positive', [25 70 180], [15 40;60 90;160 200], 'method', 'largest', 'samples', 5 );
EEG = pop_tesa_peakanalysis( EEG, 'ROI', 'negative', [45 100], [35 50;80 110], 'method', 'largest', 'samples', 5 );

% Step 23: Output peak analysis in table
outputLeftMotor = pop_tesa_peakoutput( EEG, 'tepName', 'LeftMotor', 'calcType', 'amplitude', 'winType', 'individual', 'averageWin', [], 'fixedPeak', [], 'tablePlot', 'on' );
outputRightMotor = pop_tesa_peakoutput( EEG, 'tepName', 'RightMotor', 'calcType', 'amplitude', 'winType', 'individual', 'averageWin', [], 'fixedPeak', [], 'tablePlot', 'on' );
outputLeftPFC = pop_tesa_peakoutput( EEG, 'tepName', 'LeftFPN', 'calcType', 'amplitude', 'winType', 'individual', 'averageWin', [], 'fixedPeak', [], 'tablePlot', 'on' );
outputRightPFC = pop_tesa_peakoutput( EEG, 'tepName', 'RightFPN', 'calcType', 'amplitude', 'winType', 'individual', 'averageWin', [], 'fixedPeak', [], 'tablePlot', 'on' );
outputLeftDMN = pop_tesa_peakoutput( EEG, 'tepName', 'LeftDMN', 'calcType', 'amplitude', 'winType', 'individual', 'averageWin', [], 'fixedPeak', [], 'tablePlot', 'on' );
outputRightDMN = pop_tesa_peakoutput( EEG, 'tepName', 'RightDMN', 'calcType', 'amplitude', 'winType', 'individual', 'averageWin', [], 'fixedPeak', [], 'tablePlot', 'on' );

close all
% Step 24: Plot TEPs per ROI
pop_tesa_plot( EEG, 'tepType', 'ROI', 'tepName', 'LeftMotor', 'xlim', [-100 500], 'ylim', [], 'CI','off','plotPeak','off' ); saveas(figure(1),[[FileDir,[erase(name, '.vhdr')]] '/LeftMotor.tiff'])
pop_tesa_plot( EEG, 'tepType', 'ROI', 'tepName', 'RightMotor', 'xlim', [-100 500], 'ylim', [], 'CI','off','plotPeak','off' ); saveas(figure(2),[[FileDir,[erase(name, '.vhdr')]] '/RightMotor.tiff'])
pop_tesa_plot( EEG, 'tepType', 'ROI', 'tepName', 'LeftFPN', 'xlim', [-100 250], 'ylim', [], 'CI','off','plotPeak','off' ); saveas(figure(3),[[FileDir,[erase(name, '.vhdr')]] '/LeftFPN.tiff'])
pop_tesa_plot( EEG, 'tepType', 'ROI', 'tepName', 'RightFPN', 'xlim', [-50 200], 'ylim', [], 'CI','off','plotPeak','off' ); saveas(figure(4),[[FileDir,[erase(name, '.vhdr')]] '/RightFPN.tiff'])
pop_tesa_plot( EEG, 'tepType', 'ROI', 'tepName', 'LeftDMN', 'xlim', [-100 250], 'ylim', [], 'CI','off','plotPeak','off' ); saveas(figure(5),[[FileDir,[erase(name, '.vhdr')]] '/LeftDMN.tiff'])
pop_tesa_plot( EEG, 'tepType', 'ROI', 'tepName', 'RightDMN', 'xlim', [-50 200], 'ylim', [], 'CI','off','plotPeak','off' ); saveas(figure(6),[[FileDir,[erase(name, '.vhdr')]] '/RightDMN.tiff'])

